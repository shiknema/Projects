import { useEffect, useState } from "react";
import "./App.css";
import testData from "./testData.json";
import { ReactComponent as Logo } from "./melon.svg";

function App() {

  const sortedData = [];
  if (testData.length > 0) {
    for (let i = 0; i < testData.length; i++) {
      for (let j = 0; j < testData[i].testData.length; j++) {
        const data = testData[i].testData[j];
        data.sport.sportName = data.sport.sportName.toLowerCase();  
        sortedData.push(data);
      }
    }
  }
  const [width, setWidth] = useState(window.innerWidth);

  function handleWindowSizeChange() {
    setWidth(window.innerWidth);
  }
  useEffect(() => {
    window.addEventListener("resize", handleWindowSizeChange);
    return () => {
      window.removeEventListener("resize", handleWindowSizeChange);
    };
  }, []);

  const isMobile = width <= 375;

  return (
    <div className="App">
      <div id="header">
        <Logo className="custom-melon"  />
        <p>Playtech Sports Assignment</p>
      </div>
      <div id="page">
        {!isMobile && <div id="sideBar"></div>}
        <div id="content">
          {!isMobile &&
            sortedData.sort((a, b) => parseInt(a.market.marketId) > parseInt(b.market.marketId)
              ? -1
              : 1
            )
              .map((a, i) => {
                return (
                  <div key={i.toString()} className="sport-event">
                    <p> MarketID: {a.market.marketId}</p>
                    <p> Sport: {a.sport.sportName}</p>
                    <p> SportID: {a.sport.eventId}</p>
                  </div>
                );
              })}
          {isMobile &&
            sortedData
              .sort((a, b) =>
                parseInt(a.market.marketId) > parseInt(b.market.marketId)
                  ? 1
                  : -1
              )
              .map((a, i) => {
                return (
                  <div key={i.toString()} className="sport-event">
                    <p> MarketID: {a.market.marketId}</p>
                    <p> Sport: {a.sport.sportName}</p>
                    <p> SportID: {a.sport.eventId}</p>
                  </div>
                );
              })}
        </div>
      </div>
    </div>
  );
}

export default App;
