//import logo from './logo.svg';
import React, { Component } from "react";
    import PostData from "./testData.json";
import './App.css';

function App() {
  return (
    <div class="parent">
      <div class="row ">
        <div class="child-1">1</div>
        <div class="child-wrapper">
          <div class="child-2">2</div>
          <div class="center-child">
            <div class="child">3</div>
            <div class="child">3</div>
            <div class="child">3</div>
            <div class="child">3</div>
          </div>
        </div>
      </div>
      
      <div className="flex flex-row bg-gray-400 w-2/3 mx-auto mt-10">
 {PostData.map((testData) => {
              return (                
                  <div className="text-center w-1/4 p-2 m-2 bg-white">
                   {/**  <img className="w-64 h-64" src={postDetail.image} alt="" />*/}
                    <h1>{testData.market}</h1>
                    
                  </div>

              );
            })}
  </div>

    </div >
  );
}

export default App;
